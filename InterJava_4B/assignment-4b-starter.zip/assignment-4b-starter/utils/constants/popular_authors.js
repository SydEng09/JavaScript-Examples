export const POPULAR_AUTHORS = [
    {
        name: 'J.K. Rowling',
        key: 'OL23919A'
    },
    {
        name: 'J.R.R. Tolkien',
        key: 'OL26320A'
    },
    {
        name: 'Robert Jordan',
        key: 'OL2645644A'
    },
    {
        name: 'Aldous Huxley',
        key: 'OL19767A'
    },
    {
        name: 'George Orwell',
        key: 'OL118077A'
    }
]